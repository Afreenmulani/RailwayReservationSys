using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using RailwayReservationSystem.Models;
namespace RailwayReservation.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TrainController : Controller
    {
        private readonly RailwayReservationSystemContext _context;
 
        public TrainController(RailwayReservationSystemContext context)
        {
            _context = context;
        }
 
        // GET: api/Train
        [HttpGet ("trains")]
        public async Task<IActionResult> Index()
        {
            var train = await _context.Trains.ToListAsync();
            return Ok(train);
        }
 
       [HttpGet("search")]
public async Task<IActionResult> Search([FromQuery] string source, [FromQuery] string destination)
{
    if (string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(destination))
    {
        return BadRequest("Source and destination cannot be empty.");
    }
 
    // Convert both source and destination to lower case for comparison
    var trains = await _context.Trains
        .Where(t => t.Source.ToLower() == source.ToLower() &&
                    t.Destination.ToLower() == destination.ToLower())
        .ToListAsync();
 
    if (trains == null || trains.Count == 0)
    {
        return NotFound("No trains found for the given source and destination.");
    }
 
    return Ok(trains);
}

 //search by using id
     [HttpGet("search/{id}")]
     public IActionResult GetTrainById(int id)
    {
        var train = _context.Trains.FirstOrDefault(t => t.TrainId == id);
        if (train == null)
        {
            return NotFound(new { Message = "Train not found." });
        }
        return Ok(train);
    }
//search by using name
     [HttpGet("searchByName")]
     public IActionResult SearchTrainsByName(string trainName)
    {
        
 
        var trains = _context.Trains
            .Where(t => t.TrainName.Contains(trainName))
            .ToList();
 
        if (!trains.Any())
        {
            return NotFound(new { Message = "No trains found with the specified name." });
        }
 
        return Ok(trains);
    }
 
    }
}
 