using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using RailwayReservationSystem.Models;
 
namespace RailwayReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        
        private readonly RailwayReservationSystemContext _context;
        
        
        public ReservationController(RailwayReservationSystemContext context)
        {
            _context = context;
        }

        
 
        [HttpPost("add")]
public async Task<IActionResult> Create([FromBody] List<Reservation> reservations)
{
    var loggedInUsername = HttpContext.Session.GetString("Username");
    var loggedInPassengerId = HttpContext.Session.GetInt32("PassengerId");
 
            if (string.IsNullOrEmpty(loggedInUsername) || loggedInPassengerId == null)
            {
                return Unauthorized(new { message = "You must be logged in to update your details." });
            }
 
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
    
    var primaryPassenger = await _context.Passengers.FirstOrDefaultAsync(p => p.PassengerId == reservations[0].PassengerId);

                                         
    if (primaryPassenger == null)
    {
        return BadRequest("Invalid primary passenger ID.");
    }

    
    foreach (var reservation in reservations)
    {
        if (reservation.Pnr != null) 
        {
            return BadRequest("Pnr should not be provided in the request body.");
        }

        
        if (reservation.Gender == "Male" && reservation.Quota == "Ladies")
        {
            return BadRequest("Male passengers cannot be booked under the Ladies quota.");
        }

        
        var familyMember = await _context.Passengers.FirstOrDefaultAsync(p => p.PassengerId == reservation.PassengerId);
        if (familyMember == null)
        {
            
            familyMember = new Passenger
            {
                PassengerId = reservation.PassengerId,
                Name = reservation.PassengerName,
                Gender = reservation.Gender,
                Age = reservation.Age,
                
            };
            _context.Passengers.Add(familyMember);
            await _context.SaveChangesAsync();
        }

        reservation.Pnr = GeneratePnr(); 
        var train = await _context.Trains.FirstOrDefaultAsync(train => train.TrainId == reservation.TrainId);
        if (train == null)
        {
            return BadRequest("Invalid train ID.");
        }

        
        if (train.AvailableSeats <= 0)
        {
            reservation.TicketStatus = "Waiting"; 
        }
        else
        {
            reservation.TicketStatus = "Confirmed"; 
            train.AvailableSeats -= 1; 
        }

        
        if (reservation.ReservationDate < DateTime.Today)
        {
            ModelState.AddModelError("ReservationDate", "Reservation date must be today or in the future.");
        }
        

        reservation.Fare = train.Fare; 
         if (reservation.Quota == "Ladies")
        {
            reservation.Fare = reservation.Fare * 0.5; // 50% discount
        }
        if (reservation.Age<=5)
        {
            reservation.Fare =0; 
        }
    }

    
    if (ModelState.IsValid)
    {
        
        _context.AddRange(reservations);
        await _context.SaveChangesAsync();

        
        var response = reservations.Select(reservation => new
        {
            Pnr = reservation.Pnr,
            TicketStatus = reservation.TicketStatus,
            TrainId = reservation.TrainId,
            TrainName = _context.Trains.FirstOrDefault(t => t.TrainId == reservation.TrainId)?.TrainName,
            Fare = reservation.Fare,
            Message = "Ticket reserved successfully"
        }).ToList();

        return Ok(response);
    }

    return BadRequest(ModelState); 
}



    
    private string GeneratePnr()
    {
        Random random = new Random();
        int numberPart = random.Next(100, 1000); 
        return $"PNR{numberPart}"; 
    }

       
 
        // DELETE: api/reservation/cancel/{pnr}
        [HttpDelete("cancel/{pnr}")]
        public async Task<IActionResult> CancelReservation(string pnr)
        {
            var reservation = await _context.Reservations.FirstOrDefaultAsync(r => r.Pnr == pnr);
            if (reservation == null)
            {
                return BadRequest("PNR does not exist");
            }
            var train = await _context.Trains.FirstOrDefaultAsync(train => train.TrainId == reservation.TrainId);
            if (train == null)
            {
                return BadRequest("Invalid train ID.");
            }
 
            _context.Reservations.Remove(reservation);
             train.AvailableSeats += 1;
            await _context.SaveChangesAsync();
            return Content("ticket is cancelled");
        }

        [HttpPost("logout")]
        public IActionResult Logout()
        {
        // Clear the session to log out the user
         HttpContext.Session.Clear();

        return Ok("Logged out successfully.");
        }
 
        
    }
}