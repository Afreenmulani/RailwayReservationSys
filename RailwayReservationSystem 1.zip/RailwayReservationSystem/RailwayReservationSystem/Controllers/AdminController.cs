using Microsoft.AspNetCore.Mvc;
using RailwayReservationSystem.Models;
using System.Threading.Tasks;
 
namespace RailwayReservation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly RailwayReservationSystemContext _context;
 
        // Example Admin credentials (for demonstration)
        private const int ValidAdminId = 1;
        private const string ValidPassword = "Password";
 
        // Store admin login status in a static variable for simplicity
        private static bool IsAdminLoggedIn = false;
 
        public AdminController(RailwayReservationSystemContext context)
        {
            _context = context;
        }
 
        // POST: api/admin/login
        [HttpPost("login")]
        public IActionResult Login(Admin admin)
        {
            // Validate admin credentials
            if (admin.AdminId == ValidAdminId && admin.Password == ValidPassword)
            {
                IsAdminLoggedIn = true; // Mark the admin as logged in
                return Ok(new { message = "Login successful!" });
            }
 
            // If credentials are wrong, return Unauthorized
            return Unauthorized(new { message = "Invalid username or password." });
        }
 
        // PUT: api/admin/update-train/{id}
        [HttpPut("update-train/{id}")]
        public async Task<IActionResult> UpdateTrain(int id,Train updatedTrain)
        {
            // Check if admin is authenticated
            if (!IsAdminLoggedIn)
            {
                return Unauthorized(new { message = "Admin authentication required." });
            }
 
            if (id != updatedTrain.TrainId)
            {
                return BadRequest(new { message = "Train ID mismatch." });
            }
 
            var train = await _context.Trains.FindAsync(id);
            if (train == null)
            {
                return NotFound(new { message = "Train not found." });
            }
 
            // Update train details
            train.TrainName = updatedTrain.TrainName;
            train.Source = updatedTrain.Source;
            train.Destination = updatedTrain.Destination;
            train.DepartureTime = updatedTrain.DepartureTime;
            train.ArrivalTime = updatedTrain.ArrivalTime;
            train.TotalSeats = updatedTrain.TotalSeats;
            train.AvailableSeats = updatedTrain.AvailableSeats;
            train.Fare = updatedTrain.Fare;
 
            _context.Trains.Update(train);
            await _context.SaveChangesAsync();
 
            return Ok(new { message = "Train updated successfully!" });
        }
 
        // POST: api/admin/add-train
        [HttpPost("add-train")]
        public async Task<IActionResult> AddTrain(Train newTrain)
        {
            // Check if admin is authenticated
            if (!IsAdminLoggedIn)
            {
                return Unauthorized(new { message = "Admin authentication required." });
            }
 
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return validation errors if any
            }
 
            // Add the new train to the database
            _context.Trains.Add(newTrain);
            await _context.SaveChangesAsync();
 
            return Ok(new { message = "Train added successfully!" });
        }
 
        // POST: api/admin/logout
        [HttpPost("logout")]
        public IActionResult Logout()
        {
            IsAdminLoggedIn = false; // Logout the admin
            return Ok(new { message = "Logged out successfully!" });
        }
    }
}