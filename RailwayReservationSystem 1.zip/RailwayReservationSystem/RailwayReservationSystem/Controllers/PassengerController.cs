using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RailwayReservationSystem.Models;
using Microsoft.AspNetCore.Http;  // For session management
 
namespace RailwayReservationSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PassengerController : ControllerBase
    {
        private readonly RailwayReservationSystemContext _context;
 
        public PassengerController(RailwayReservationSystemContext context)
        {
            _context = context;
        }
 
        // POST: api/passenger/register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Passenger passenger)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
 
            // Check if the username already exists
            if (await _context.Passengers.AnyAsync(p => p.Username == passenger.Username))
            {
                return Conflict(new { message = "Username already exists." });
            }
 
            // Save the passenger details
            _context.Passengers.Add(passenger);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Registration successful!" });
        }
 
        // POST: api/passenger/login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest loginRequest)
        {
            var passenger = await _context.Passengers
                .FirstOrDefaultAsync(p => p.Username == loginRequest.Username && p.Password == loginRequest.Password);
 
            if (passenger != null)
            {
                // Set session data after successful login
                HttpContext.Session.SetString("Username", passenger.Username);
                HttpContext.Session.SetInt32("PassengerId", passenger.PassengerId);
 
                return Ok(new { message = "Login successful!" });
            }
 
            return Unauthorized(new { message = "Invalid username or password." });
        }
 
        // GET: api/passenger
        [HttpGet("passengers")]
        public async Task<IActionResult> GetAllPassengers()
        {
            var passengers = await _context.Passengers.ToListAsync();
            return Ok(passengers);
        }
 
        // PUT: api/passenger/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePassenger(int id, Passenger updatedPassenger)
        {
            // Ensure the user is logged in by checking the session
            var loggedInUsername = HttpContext.Session.GetString("Username");
            var loggedInPassengerId = HttpContext.Session.GetInt32("PassengerId");
 
            if (string.IsNullOrEmpty(loggedInUsername) || loggedInPassengerId == null)
            {
                return Unauthorized(new { message = "You must be logged in to update your details." });
            }
 
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
 
            var passenger = await _context.Passengers.FindAsync(id);
            if (passenger == null)
            {
                return NotFound(new { message = "Passenger not found." });
            }
 
            // Update passenger details
            passenger.Name = updatedPassenger.Name;
            passenger.Gender = updatedPassenger.Gender;
            passenger.Age = updatedPassenger.Age;
            passenger.Address = updatedPassenger.Address;
            passenger.Username = updatedPassenger.Username;
            passenger.Password = updatedPassenger.Password;
 
            _context.Passengers.Update(passenger);
            await _context.SaveChangesAsync();
 
            return Ok(new { message = "Passenger details updated successfully!" });
        }
 
        // POST: api/passenger/logout
        [HttpPost("logout")]
        public IActionResult Logout()
        {
            // Clear the session (logout the user)
            HttpContext.Session.Clear();
            return Ok(new { message = "Logged out successfully!" });
        }
    }
}