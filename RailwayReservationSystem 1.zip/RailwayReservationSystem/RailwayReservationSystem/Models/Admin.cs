using System.ComponentModel.DataAnnotations;
namespace RailwayReservationSystem.Models
{
 
public class Admin
{
    public int AdminId { get; set; }
    [Required(ErrorMessage = "Password is required.")]
    public string Password { get; set; }=null!; // Ensure this is stored securely (hashed) in a real application
}
}