﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
 
 
namespace RailwayReservationSystem.Models;
 
public partial class Train
{
    [Key]
    public int TrainId { get; set; }
 
    [Required(ErrorMessage = "Train name is required.")]
    [StringLength(100, ErrorMessage = "Train name cannot be longer than 100 characters.")]
    public string TrainName { get; set; } = null!;
 
    [Required(ErrorMessage = "Source is required.")]
    public string Source { get; set; } = null!;
 
    [Required(ErrorMessage = "Destination is required.")]
    public string Destination { get; set; } = null!;
 
    [Required(ErrorMessage = "Departure time is required.")]
    public DateTime DepartureTime { get; set; }
 
    [Required(ErrorMessage = "Arrival time is required.")]
    public DateTime ArrivalTime { get; set; }
 
    [Range(1, int.MaxValue, ErrorMessage = "Total seats must be at least 1.")]
    public int TotalSeats { get; set; }
 
    [Range(0, int.MaxValue, ErrorMessage = "Available seats cannot be negative.")]
    public int AvailableSeats { get; set; }
 
    [Range(0, double.MaxValue, ErrorMessage = "Fare must be a positive number.")]
    public double Fare { get; set; }
 
    public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
}