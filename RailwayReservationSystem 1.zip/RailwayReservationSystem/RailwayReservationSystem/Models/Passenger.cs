﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace RailwayReservationSystem.Models;
 
public partial class Passenger
{
    [Key]
    public int PassengerId { get; set; }
 
    [Required(ErrorMessage = "Name is required.")]
    [StringLength(100, ErrorMessage = "Name cannot be longer than 100 characters.")]
    [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Name can only contain letters and spaces.")]  
    public string Name { get; set; } = null!;
 
    [Required(ErrorMessage = "Gender is required.")]
    [RegularExpression("^(Male|Female|Other)$", ErrorMessage = "Gender must be Male, Female, or Other.")]
    public string Gender { get; set; } = null!;
 
    [Range(0, 120, ErrorMessage = "Age must be between 0 and 120.")]
    public int? Age { get; set; }
 
    [StringLength(250, ErrorMessage = "Address cannot be longer than 250 characters.")]
    public string? Address { get; set; }
 
    [Required(ErrorMessage = "Username is required.")]
    [StringLength(50, ErrorMessage = "Username cannot be longer than 50 characters.")]
    public string Username { get; set; } = null!;
 
    [Required(ErrorMessage = "Password is required.")]
    [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long.")]
    [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).+$",
    ErrorMessage = "Password must contain at least one lowercase letter, one uppercase letter, one digit, and one special character.")]    
    public string Password { get; set; } = null!;
 
    public virtual ICollection<Reservation> Reservations { get; set; } = new List<Reservation>();
}