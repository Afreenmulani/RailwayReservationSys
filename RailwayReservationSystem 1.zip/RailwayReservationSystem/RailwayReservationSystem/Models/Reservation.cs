﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
 
namespace RailwayReservationSystem.Models;
 
 
public partial class Reservation
{
    [Key]
    public int ReservationId { get; set; }
 
 
    public int PassengerId { get; set; }
 
 [Required(ErrorMessage = "Train Id is required.")]
    public int TrainId { get; set; }
 
    [Required(ErrorMessage = "Passenger Name is required.")]
    public string PassengerName { get; set; } = null!;
 
    
    public string Gender { get; set; } = null!;
 
    [Range(0, 120, ErrorMessage = "Age must be between 0 and 120.")]
    public int Age { get; set; }
 
    public int CreditNo { get; set; }
 
    
    public string? BankName { get; set; }
 
    
    public string? Quota { get; set; }
 
    public string? Pnr { get; set; } = null!;
 
    [Required(ErrorMessage = "Reservation date is required.")]
    public DateTime ReservationDate { get; set; }
 
    public string? TicketStatus { get; set; } = null!;
 
    [Required(ErrorMessage = "Source is required.")]
    public string Source { get; set; } = null!;
 
    [Required(ErrorMessage = "Destination is required.")]
    public string Destination { get; set; } = null!;
 
    public double Fare { get; set; }
 
    public virtual Passenger? Passenger { get; set; }
 
    public virtual Train? Train { get; set; }
}