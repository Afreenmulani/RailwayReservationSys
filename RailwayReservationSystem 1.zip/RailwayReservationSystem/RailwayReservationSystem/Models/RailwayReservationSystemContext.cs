﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace RailwayReservationSystem.Models;

public partial class RailwayReservationSystemContext : DbContext
{
    public RailwayReservationSystemContext()
    {
    }

    public RailwayReservationSystemContext(DbContextOptions<RailwayReservationSystemContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Passenger> Passengers { get; set; }

    public virtual DbSet<Reservation> Reservations { get; set; }

    public virtual DbSet<Train> Trains { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=RailwayReservationSystem");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Passenger>(entity =>
        {
            entity.HasKey(e => e.PassengerId).HasName("PK__Passenge__88915F9066C70736");

            entity.Property(e => e.PassengerId).HasColumnName("PassengerID");
            entity.Property(e => e.Address).HasMaxLength(200);
            entity.Property(e => e.Gender).HasMaxLength(10);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Password).HasMaxLength(50);
            entity.Property(e => e.Username).HasMaxLength(50);
        });

        modelBuilder.Entity<Reservation>(entity =>
        {
            entity.HasKey(e => e.ReservationId).HasName("PK__Reservat__B7EE5F24F6F40F22");

            entity.HasIndex(e => e.Pnr, "UQ__Reservat__C5773DD302CB3240").IsUnique();

            entity.Property(e => e.BankName)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Gender).HasMaxLength(10);
            entity.Property(e => e.PassengerId).HasColumnName("PassengerID");
            entity.Property(e => e.PassengerName).HasMaxLength(100);
            entity.Property(e => e.Pnr)
                .HasMaxLength(20)
                .HasColumnName("PNR");
            entity.Property(e => e.Quota)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.ReservationDate).HasColumnType("datetime");
            entity.Property(e => e.TicketStatus).HasMaxLength(20);

            entity.HasOne(d => d.Passenger).WithMany(p => p.Reservations)
                .HasForeignKey(d => d.PassengerId)
                .HasConstraintName("FK__Reservati__Passe__3B75D760");

            entity.HasOne(d => d.Train).WithMany(p => p.Reservations)
                .HasForeignKey(d => d.TrainId)
                .HasConstraintName("FK__Reservati__Train__3C69FB99");
        });

        modelBuilder.Entity<Train>(entity =>
        {
            entity.HasKey(e => e.TrainId).HasName("PK__Trains__8ED2723AE64837E4");

            entity.Property(e => e.ArrivalTime).HasColumnType("datetime");
            entity.Property(e => e.DepartureTime).HasColumnType("datetime");
            entity.Property(e => e.Destination).HasMaxLength(100);
            entity.Property(e => e.Fare).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Source).HasMaxLength(100);
            entity.Property(e => e.TrainName).HasMaxLength(100);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
