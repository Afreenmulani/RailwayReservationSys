using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using RailwayReservationSystem.Models;
 
var builder = WebApplication.CreateBuilder(args);
 
// Add services to the container.
 
// Configure Entity Framework context to use SQL Server.
builder.Services.AddDbContext<RailwayReservationSystemContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("RailwayReservationSystem")));
 
// Add MVC services for controllers with views
builder.Services.AddControllersWithViews();
 
// Add in-memory cache and session services.
builder.Services.AddDistributedMemoryCache(); // used to check whether user is log in or not
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(1); // Session timeout of 1 minute
});
// tells at how much time the session should be alive
 
// Configure Cookie Authentication for Admin login.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)// check to when user are is still login or not
    .AddCookie(options =>
    {
        // Set login and access denied paths for authentication
        options.LoginPath = "/api/admin/login"; // for updating logging is  req without login it will not update
        options.AccessDeniedPath = "/api/admin/access-denied"; // when you are user are you are trying to access url that only access by admin
         options.LoginPath = "/api/passenger/login"; // Redirect to login if not authenticated
        options.LogoutPath = "/api/passenger/logout"; // Logout URL
        options.ExpireTimeSpan = TimeSpan.FromMinutes(1); // Session expiration time
        options.SlidingExpiration = true; // Refresh the cookie expiration time with every request
    });

    
 
var app = builder.Build();
 
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
 
//app.UseHttpsRedirection();
app.UseStaticFiles();
 
// Enable routing for the app.
app.UseRouting();
 
// Enable session middleware to store data for the session duration.
app.UseSession();
 
// Enable authentication and authorization middleware.
app.UseAuthentication(); // check users authentication like cookie
app.UseAuthorization(); // the resuorces should be access who has permission to access
 
// Set up default controller routes for MVC.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
 
app.Run();